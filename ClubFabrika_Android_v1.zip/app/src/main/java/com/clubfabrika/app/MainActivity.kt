package com.clubfabrika.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClubFabrikaApp() }
    }
}

@Composable
fun ClubFabrikaApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF6C3BFF),
            secondary = Color(0xFFFF4F8B),
            background = Color(0xFFF7F7FB)
        )
    ) {
        val nav = rememberNavController()
        NavHost(navController = nav, startDestination = "dashboard") {
            composable("dashboard") { Dashboard(nav) }
            composable("reviews") { SimplePage("Reviews", "Manage and generate AI replies to customer reviews.") }
            composable("seo") { SimplePage("SEO", "Track keywords, visibility and optimization opportunities.") }
            composable("competitors") { SimplePage("Competitors", "Monitor competitor activity and discover opportunities.") }
            composable("content") { SimplePage("AI Content", "Create posts, captions and marketing ideas.") }
            composable("profile") { SimplePage("Profile", "Business account and application settings.") }
        }
    }
}

@Composable
fun Dashboard(nav: NavHostController) {
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavItem(nav, "dashboard", Icons.Default.Home, "Home")
                NavItem(nav, "reviews", Icons.Default.Star, "Reviews")
                NavItem(nav, "content", Icons.Default.Create, "AI")
                NavItem(nav, "profile", Icons.Default.Person, "Profile")
            }
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Club Fabrika", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Your AI marketing workspace", color = Color.Gray)
            }
            item {
                Card(shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Business Health", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Text("78 / 100", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6C3BFF))
                        Text("Good — 5 improvements available", color = Color.Gray)
                        Spacer(Modifier.height(14.dp))
                        LinearProgressIndicator(progress = { .78f }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item { FeatureCard("AI Content", "Generate social posts and Google updates", "content", nav) }
            item { FeatureCard("Reviews", "Create helpful AI replies to customers", "reviews", nav) }
            item { FeatureCard("SEO", "Find keywords and improve visibility", "seo", nav) }
            item { FeatureCard("Competitors", "See what nearby competitors are doing", "competitors", nav) }
        }
    }
}

@Composable
fun FeatureCard(title: String, description: String, route: String, nav: NavHostController) {
    Card(
        onClick = { nav.navigate(route) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(description, color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Text("Open →", color = Color(0xFF6C3BFF), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SimplePage(title: String, description: String) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(description, color = Color.Gray, fontSize = 16.sp)
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Coming next", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("This module is ready for the Club Fabrika backend and AI/API integration.")
            }
        }
    }
}

@Composable
fun RowScope.NavItem(nav: NavHostController, route: String, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    NavigationBarItem(
        selected = false,
        onClick = { nav.navigate(route) },
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) }
    )
}
