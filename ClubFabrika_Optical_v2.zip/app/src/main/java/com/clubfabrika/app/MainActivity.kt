package com.clubfabrika.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClubFabrikaApp() }
    }
}

@Composable
fun ClubFabrikaApp() {
    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF6C3BFF),
        secondary = Color(0xFFFF4F8B),
        background = Color(0xFFF7F7FB)
    )) {
        val nav = rememberNavController()
        NavHost(nav, "home") {
            composable("home") { Home(nav) }
            composable("ai") { AiMarketing() }
            composable("reviews") { Reviews() }
            composable("seo") { Seo() }
            composable("competitors") { Competitors() }
            composable("offers") { Offers() }
            composable("calendar") { CalendarPage() }
            composable("profile") { Profile() }
        }
    }
}

@Composable
fun Shell(title: String, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }) }
    ) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(20.dp), content = content)
    }
}

@Composable
fun Home(nav: NavHostController) {
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(true, { nav.navigate("home") }, { Icon(Icons.Default.Home, null) }, { Text("Home") })
            NavigationBarItem(false, { nav.navigate("ai") }, { Icon(Icons.Default.Create, null) }, { Text("AI") })
            NavigationBarItem(false, { nav.navigate("reviews") }, { Icon(Icons.Default.Star, null) }, { Text("Reviews") })
            NavigationBarItem(false, { nav.navigate("profile") }, { Icon(Icons.Default.Person, null) }, { Text("Profile") })
        }
    }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Text("Club Fabrika", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Optical Store Growth • बिज़नेस ग्रोथ", color = Color.Gray)
            }
            item {
                Card(shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Business Health / बिज़नेस हेल्थ", fontWeight = FontWeight.Bold)
                        Text("78 / 100", fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6C3BFF))
                        Text("Good — 5 improvements available", color = Color.Gray)
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator({ .78f }, Modifier.fillMaxWidth())
                    }
                }
            }
            item { Quick("🤖", "AI Marketing", "AI posts, captions & Google updates", "ai", nav) }
            item { Quick("⭐", "Customer Reviews", "AI replies & review management", "reviews", nav) }
            item { Quick("🔎", "Local SEO", "Google visibility & keywords", "seo", nav) }
            item { Quick("🏪", "Competitors", "Nearby optical store insights", "competitors", nav) }
            item { Quick("🏷️", "Offers", "Create optical offers", "offers", nav) }
            item { Quick("📅", "Content Calendar", "Plan your weekly marketing", "calendar", nav) }
        }
    }
}

@Composable
fun Quick(icon: String, title: String, desc: String, route: String, nav: NavHostController) {
    Card(onClick = { nav.navigate(route) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("$icon  $title", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Color.Gray)
            Spacer(Modifier.height(8.dp))
            Text("Open →", color = Color(0xFF6C3BFF), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable fun AiMarketing() = Shell("AI Marketing / AI मार्केटिंग") {
    Text("What do you want to promote?", fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Spacer(Modifier.height(10.dp))
    listOf("👓 New Frames", "🕶️ Sunglasses", "👁️ Eye Check-up", "🧿 Contact Lenses", "🏷️ Discount / Offer", "🎉 Festival Offer", "🆕 New Collection").forEach {
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(it) }
    }
    Spacer(Modifier.height(10.dp))
    Button(onClick = {}, Modifier.fillMaxWidth()) { Text("Generate AI Post / AI पोस्ट बनाएं") }
}

@Composable fun Reviews() = Shell("Reviews / रिव्यू") {
    Text("AI Reply Generator", fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Paste customer review here...") })
    Spacer(Modifier.height(12.dp))
    Button(onClick = {}, Modifier.fillMaxWidth()) { Text("Generate Reply / जवाब बनाएं") }
}

@Composable fun Seo() = Shell("Local SEO / लोकल SEO") {
    Text("Optical store visibility", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text("Suggested keywords", color = Color.Gray)
    listOf("optical shop near me", "eye glasses near me", "best optical store", "sunglasses shop").forEach {
        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(it, Modifier.padding(15.dp)) }
    }
}

@Composable fun Competitors() = Shell("Competitors / कॉम्पिटिटर्स") {
    Text("Nearby optical competitors", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text("Live competitor data will connect through the backend/API.", color = Color.Gray)
}

@Composable fun Offers() = Shell("Offers / ऑफर्स") {
    Text("Create an offer", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    listOf("Frame + Lens Combo", "Sunglasses Discount", "Free Eye Check-up", "Contact Lens Offer").forEach {
        Button(onClick = {}, Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(it) }
    }
}

@Composable fun CalendarPage() = Shell("Content Calendar / कंटेंट कैलेंडर") {
    listOf("Monday • New Frames", "Wednesday • Eye Check-up", "Friday • Sunglasses", "Sunday • Customer Review").forEach {
        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(it, Modifier.padding(16.dp)) }
    }
}

@Composable fun Profile() = Shell("Store Profile / स्टोर प्रोफाइल") {
    Text("Optical Store Details", fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Spacer(Modifier.height(12.dp))
    OutlinedTextField("", {}, Modifier.fillMaxWidth(), label = { Text("Store Name") })
    Spacer(Modifier.height(10.dp))
    OutlinedTextField("", {}, Modifier.fillMaxWidth(), label = { Text("City") })
    Spacer(Modifier.height(10.dp))
    Button(onClick = {}, Modifier.fillMaxWidth()) { Text("Save / सेव करें") }
}
